AMWALI Print Bridge - Quick Install
===================================
1. Extract this folder to:  C:\print-bridge
2. Install Node.js LTS:     https://nodejs.org/en/download
3. Right-click install-bridge.bat -> Run as administrator
4. Open in browser:         http://127.0.0.1:3001/health
